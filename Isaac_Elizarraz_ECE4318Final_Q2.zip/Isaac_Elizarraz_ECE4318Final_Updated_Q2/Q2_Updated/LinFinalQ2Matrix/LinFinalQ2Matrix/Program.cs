﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinFinalQ2Matrix
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Matrix A: \n");
            double[,] a = { { 1, 1 }, { 1, 0 } };
            myMatrix A = new myMatrix(a);
            A.GetMatrices();
        
            Console.WriteLine("Matrix B: \n");
            double[,] b = { { 1, 1 }, { 0, 1 } };
            myMatrix B = new myMatrix(b);
            B.GetMatrices();
           
            Console.WriteLine("Matrix C: \n");
            double[,] c = { { 1, 1 }, { 1, 1 } };
            myMatrix C = new myMatrix(c);
            C.GetMatrices();

            Console.WriteLine("Matrix A + Matrix B: \n");
            A.Add(B).GetMatrices();

            Console.WriteLine("Matrix A - Matrix B: \n");
            A.Subtract(B).GetMatrices();
           
            Console.WriteLine("\nMatrix C x 2: ");
            C.ScalarMul(2).GetMatrices();
            
            Console.WriteLine("\nMatrix B x Matrix A: \n\n");
            B.Multiply(A).GetMatrices();
            
            Console.WriteLine("Determinant of C:");
            Console.WriteLine(myMatrix.determinant(C.dataClass, 2));

            Console.WriteLine("\nMatrix A^10: ");
            myMatrix temp1 = new myMatrix(A);
            for (int i = 0; i < 9; i++)
            {
                temp1 = temp1.Multiply(A);
            }
            temp1.GetMatrices();
            Console.WriteLine();
            Console.WriteLine("Matrix B^10: ");
            myMatrix temp2 = new myMatrix(B);
            for (int i = 0; i < 9; i++)
            {
                temp2 = temp2.Multiply(B);
            }
            temp2.GetMatrices();


            Console.WriteLine("\nMatrix C^10: ");
            myMatrix temp3 = new myMatrix(C);
            for (int i = 0; i < 9; i++)
            {
                temp3 = temp3.Multiply(C);
            }
            temp3.GetMatrices();

            Console.WriteLine("\nMatrix A^100: ");
            myMatrix temp4 = new myMatrix(A);
            for (int i = 0; i < 99; i++)
            {
                temp4 = temp4.Multiply(A);
            }
            temp4.GetMatrices();

            Console.WriteLine("\nMatrix B^100: ");
            myMatrix temp5 = new myMatrix(B);
            for (int i = 0; i < 99; i++)
            {
                temp5 = temp5.Multiply(B);
            }
            temp5.GetMatrices();

            Console.WriteLine("\nMatrix C^100: ");
            myMatrix temp6 = new myMatrix(C);
            for (int i = 0; i < 99; i++)
            {
                temp6 = temp6.Multiply(C);
            }
            temp6.GetMatrices();
        }
    }
}
