﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinFinalQ2Matrix
{
    class myMatrix
    {
        private int M;
        private int N;
        public double[,] dataClass;


        public myMatrix(int m, int n)
        {
            M = m;
            N = n;
            dataClass = new double[M, N];
        }

        public myMatrix(double[,] data)
        {
            M = data.GetLength(0);
            N = data.GetLength(1);
            dataClass = new double[M, N];
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    dataClass[i, j] = data[i, j];
                }
            }
        }

        public myMatrix(myMatrix A) { dataClass = A.dataClass; this.N = A.N ; this.M = A.M; }

        public myMatrix identity(int N)
        {
            myMatrix I = new myMatrix(N, N);
            for (int i = 0; i < N; i++)
            { 
                I.dataClass[i, i] = 1; 
            }
            return I;
        }

        public myMatrix ScalarMul(int scalar)
        {
            myMatrix A = new myMatrix(N, M);
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    A.dataClass[j, i] = dataClass[j, i] * scalar;
                }
            }
            return A;
        }

        public myMatrix Add(myMatrix B)
        {
            myMatrix A = this;
            myMatrix C = new myMatrix(M, N);
            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                    C.dataClass[i,j] = A.dataClass[i,j] + B.dataClass[i,j];
            return C;
        }

        public myMatrix Subtract(myMatrix B)
        {
            myMatrix A = this;
            myMatrix C = new myMatrix(M, N);
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    C.dataClass[i, j] = A.dataClass[i, j] - B.dataClass[i, j];
                }
            }
            return C;
        }
        public myMatrix Multiply(myMatrix B)
        {
            myMatrix A = this;
            A.N = N;
            A.M = M;
            myMatrix C = new myMatrix(A.M, B.N);
            for (int i = 0; i < C.M; i++)
            {
                for (int j = 0; j < C.N; j++)
                {
                    for (int k = 0; k < A.N; k++)
                    {
                        C.dataClass[i, j] += (A.dataClass[i, k] * B.dataClass[k, j]);
                    }
                }
            }
            return C;
        }

        static public void getCofactor(double[,] mat, double[,] temp, int p, int q, int n)
        {
            int i = 0, j = 0;
            for (int row = 0; row < n; row++)
            {
                for (int col = 0; col < n; col++)
                {
                    if (row != p && col != q)
                    {
                        temp[i,j++] = (int)mat[row,col];
                        if (j == n - 1)
                        {
                            j = 0;
                            i++;
                        }
                    }
                }
            }
        }
        public void GetMatrices()
        {
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    Console.Write("  " + dataClass[i, j]);


                }
                Console.WriteLine();
            }

        }
        static public int determinant(double[,] mat, int n)
        {
            double D = 0;
            if (n == 1)
            { return  (int) mat[0,0]; }

            double[,] temp = new double[n,n];
		
		int sign = 1;
		
		for (int f = 0; f<n; f++) 
		{
			getCofactor(mat, temp, 0, f, n);
             D += sign* mat[0 , f] * determinant(temp, n - 1);
             sign = -sign;
		}

		return (int)D;
	}

      



    }
}