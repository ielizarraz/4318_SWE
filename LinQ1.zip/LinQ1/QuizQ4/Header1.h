#pragma once
class Methods
{
public:
	int real;
	int imag;
	void Methods();
	void add(Methods a, Methods b);
	void mul(Methods a, Methods b);
	void print(Methods a);


	Methods();


};